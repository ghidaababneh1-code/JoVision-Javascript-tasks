# JoVision React Native Tasks

This repository contains all React Native tasks for the JoVision training program.

## Task 15: Environment Setup ✅

This task involves setting up the React Native CLI development environment.

### Prerequisites Installed

- ✅ Node.js v22.13.0
- ✅ Java Development Kit (JDK) 17
- ✅ Android SDK (API Level 35 - VanillaIceCream)
- ✅ React Native CLI

### Environment Variables Configured

```bash
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin
export PATH=$PATH:$ANDROID_HOME/platform-tools
export PATH=$PATH:$ANDROID_HOME/emulator
```

### Project Structure

```
JoVisionReactNativeTasks/
├── Tasks/
│   └── Task15.tsx          # Task 15 component
├── App.tsx                 # Main app file (renders current task)
├── android/                # Android native code
├── ios/                    # iOS native code
└── package.json            # Dependencies
```

## How to Use This Repository

1. Each task will be created as a separate component in the `Tasks/` folder
2. The `App.tsx` file will be updated to render the current task being worked on
3. Task components are named according to their task number (e.g., `Task16.tsx`, `Task17.tsx`)

## Running the Project

### For Android:

```bash
# Start Metro bundler
npx react-native start

# In another terminal, run on Android
npx react-native run-android
```

### For iOS (macOS only):

```bash
# Install pods
cd ios && pod install && cd ..

# Run on iOS
npx react-native run-ios
```

## Pushing to GitHub

To push this project to your GitHub account:

1. Create a new repository on GitHub named "JoVision react native tasks"
2. Copy the repository URL (e.g., `https://github.com/YOUR_USERNAME/JoVision-react-native-tasks.git`)
3. Run the following commands:

```bash
cd ~/JoVisionReactNativeTasks
git remote add origin YOUR_REPOSITORY_URL
git branch -M main
git push -u origin main
```

## Next Tasks

Future tasks (Task 16 onwards) will be added as components in the `Tasks/` folder and rendered in `App.tsx`.

---

**Note**: This project uses React Native CLI (not Expo) as per the requirements.

