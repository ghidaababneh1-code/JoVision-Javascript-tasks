/**
 * Task 15: Setup React Native Development Environment
 * This task involves installing React Native CLI and setting up the project structure
 */

import React from 'react';
import {View, Text, StyleSheet} from 'react-native';

const Task15 = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Task 15 - Environment Setup</Text>
      <Text style={styles.description}>
        React Native CLI development environment has been successfully installed!
      </Text>
      <Text style={styles.details}>✓ Node.js installed</Text>
      <Text style={styles.details}>✓ JDK 17 installed</Text>
      <Text style={styles.details}>✓ Android SDK installed</Text>
      <Text style={styles.details}>✓ React Native CLI installed</Text>
      <Text style={styles.details}>✓ Project structure created</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  description: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
    color: '#666',
  },
  details: {
    fontSize: 14,
    marginVertical: 5,
    color: '#4CAF50',
  },
});

export default Task15;

