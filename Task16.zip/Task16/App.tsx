import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import Task16 from './Tasks/Task16';

function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Task16 />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
});

export default App;

