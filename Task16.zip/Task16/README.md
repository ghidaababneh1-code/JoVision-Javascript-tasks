# Task 16 - Show/Hide Name Component

## الوصف

هذا المكون يحقق متطلبات Task 16 من مهام JoVision React Native. يقوم بإنشاء تطبيق React Native بسيط يحتوي على زر وعند الضغط عليه يظهر أو يختفي النص.

## المتطلبات

- **زر بعنوان "Show"**: يتم عرض زر باستخدام مكون `Button` من React Native
- **نص مخفي**: يحتوي على اسم المستخدم ويكون مخفياً بشكل افتراضي
- **Toggle Functionality**: عند الضغط على الزر، يتم إظهار أو إخفاء النص بالتناوب

## التقنيات المستخدمة

- **React Hooks**: استخدام `useState` لإدارة حالة ظهور النص
- **Conditional Rendering**: استخدام العامل `&&` لعرض النص بشكل شرطي
- **Separate Functions**: تم إنشاء دالة منفصلة `handleButtonPress` لمعالجة حدث الضغط على الزر

## الكود الرئيسي

```javascript
import React, { useState } from 'react';
import { View, Button, Text, StyleSheet } from 'react-native';

function Task16() {
  const [isVisible, setIsVisible] = useState(false);

  function handleButtonPress() {
    setIsVisible(!isVisible);
  }

  return (
    <View style={styles.container}>
      <Button title="Show" onPress={handleButtonPress} />
      {isVisible && <Text style={styles.nameText}>Your Name Here</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  nameText: {
    marginTop: 20,
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default Task16;
```

## كيفية الاستخدام

### 1. إضافة المكون إلى مشروعك

قم بنسخ ملف `Task16.js` إلى مجلد `Tasks` في مشروع React Native الخاص بك:

```
YourReactNativeProject/
  ├── Tasks/
  │   └── Task16.js
  └── App.tsx
```

### 2. استيراد المكون في App.tsx

في ملف `App.tsx` الرئيسي، قم باستيراد المكون واستخدامه:

```typescript
import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import Task16 from './Tasks/Task16';

function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Task16 />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default App;
```

### 3. تشغيل التطبيق

قم بتشغيل التطبيق باستخدام الأوامر التالية:

**لنظام Android:**
```bash
npx react-native run-android
```

**لنظام iOS:**
```bash
npx react-native run-ios
```

## شرح الكود

### State Management

```javascript
const [isVisible, setIsVisible] = useState(false);
```

- يتم استخدام `useState` hook لإنشاء state يتحكم في ظهور النص
- القيمة الافتراضية هي `false` (مخفي)

### Event Handler

```javascript
function handleButtonPress() {
  setIsVisible(!isVisible);
}
```

- دالة منفصلة تقوم بعكس قيمة `isVisible`
- يتم استدعاؤها عند الضغط على الزر

### Conditional Rendering

```javascript
{isVisible && <Text style={styles.nameText}>Your Name Here</Text>}
```

- يتم عرض النص فقط عندما تكون قيمة `isVisible` هي `true`
- استخدام العامل المنطقي `&&` للعرض الشرطي

## التخصيص

يمكنك تخصيص المكون بتغيير:

1. **النص المعروض**: استبدل `"Your Name Here"` باسمك الفعلي
2. **عنوان الزر**: يمكنك تغيير `title="Show"` إلى أي نص آخر
3. **الأنماط**: قم بتعديل `styles` لتغيير المظهر

## المصادر

- [React Native Button Documentation](https://reactnative.dev/docs/button)
- [React Native Conditional Rendering](https://reactnative.dev/docs/intro-react#conditional-rendering)
- [React Hooks - useState](https://react.dev/reference/react/useState)

## ملاحظات

- تم اتباع Guidelines المطلوبة:
  - ✅ إنشاء دالة منفصلة لكل عملية
  - ✅ عدم استخدام arrow functions كـ arguments
  - ✅ استخدام functional component
  - ✅ إدارة الحالة باستخدام React Hooks

