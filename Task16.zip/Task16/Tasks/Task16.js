import React, { useState } from 'react';
import { View, Button, Text, StyleSheet } from 'react-native';

function Task16() {
  const [isVisible, setIsVisible] = useState(false);

  function handleButtonPress() {
    setIsVisible(!isVisible);
  }

  return (
    <View style={styles.container}>
      <Button title="Show" onPress={handleButtonPress} />
      {isVisible && <Text style={styles.nameText}>Your Name Here</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  nameText: {
    marginTop: 20,
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default Task16;

