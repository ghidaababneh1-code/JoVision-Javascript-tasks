import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import Task17 from './Tasks/Task17';

function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Task17 />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
});

export default App;

