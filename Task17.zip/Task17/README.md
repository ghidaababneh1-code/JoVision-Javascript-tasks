# Task 17 - Show/Hide Name with Dynamic Button Text

## الوصف

هذا المكون يحقق متطلبات Task 17 من مهام JoVision React Native. يقوم بإنشاء تطبيق React Native يحتوي على زر يتغير نصه ديناميكياً بين "Show" و "Hide" بناءً على حالة ظهور النص.

## المتطلبات

- **زر بعنوان "Show"**: يتم عرض زر باستخدام مكون `Button` من React Native
- **نص مخفي**: يحتوي على اسم المستخدم ويكون مخفياً بشكل افتراضي
- **Toggle Functionality مع تغيير نص الزر**: 
  - عند الضغط على الزر: يظهر النص + يتغير نص الزر إلى "Hide"
  - عند الضغط مرة أخرى: يختفي النص + يرجع نص الزر إلى "Show"

## الفرق عن Task 16

| Task 16 | Task 17 |
|---------|---------|
| نص الزر ثابت "Show" | نص الزر يتغير بين "Show" و "Hide" |
| State واحد فقط | State واحد + دالة لتحديد نص الزر |

## التقنيات المستخدمة

- **React Hooks**: استخدام `useState` لإدارة حالة ظهور النص
- **Conditional Rendering**: استخدام العامل `&&` لعرض النص بشكل شرطي
- **Dynamic Button Title**: دالة `getButtonTitle()` لتحديد نص الزر ديناميكياً
- **Separate Functions**: تم إنشاء دوال منفصلة لكل عملية

## الكود الرئيسي

```javascript
import React, { useState } from 'react';
import { View, Button, Text, StyleSheet } from 'react-native';

function Task17() {
  const [isVisible, setIsVisible] = useState(false);

  function handleButtonPress() {
    setIsVisible(!isVisible);
  }

  function getButtonTitle() {
    return isVisible ? 'Hide' : 'Show';
  }

  return (
    <View style={styles.container}>
      <Button title={getButtonTitle()} onPress={handleButtonPress} />
      {isVisible && <Text style={styles.nameText}>Your Name Here</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  nameText: {
    marginTop: 20,
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default Task17;
```

## كيفية الاستخدام

### 1. إضافة المكون إلى مشروعك

قم بنسخ ملف `Task17.js` إلى مجلد `Tasks` في مشروع React Native الخاص بك:

```
YourReactNativeProject/
  ├── Tasks/
  │   ├── Task16.js
  │   └── Task17.js
  └── App.tsx
```

### 2. استيراد المكون في App.tsx

في ملف `App.tsx` الرئيسي، قم باستيراد المكون واستخدامه:

```typescript
import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import Task17 from './Tasks/Task17';

function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Task17 />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default App;
```

### 3. تشغيل التطبيق

قم بتشغيل التطبيق باستخدام الأوامر التالية:

**لنظام Android:**
```bash
npx react-native run-android
```

**لنظام iOS:**
```bash
npx react-native run-ios
```

## شرح الكود

### State Management

```javascript
const [isVisible, setIsVisible] = useState(false);
```

- يتم استخدام `useState` hook لإنشاء state يتحكم في ظهور النص
- القيمة الافتراضية هي `false` (مخفي)

### Event Handler

```javascript
function handleButtonPress() {
  setIsVisible(!isVisible);
}
```

- دالة منفصلة تقوم بعكس قيمة `isVisible`
- يتم استدعاؤها عند الضغط على الزر

### Dynamic Button Title

```javascript
function getButtonTitle() {
  return isVisible ? 'Hide' : 'Show';
}
```

- **النقطة الرئيسية في Task 17**: دالة منفصلة لتحديد نص الزر
- تستخدم ternary operator للاختيار بين "Hide" و "Show"
- عندما يكون النص ظاهراً (`isVisible === true`)، يعرض "Hide"
- عندما يكون النص مخفياً (`isVisible === false`)، يعرض "Show"

### Conditional Rendering

```javascript
{isVisible && <Text style={styles.nameText}>Your Name Here</Text>}
```

- يتم عرض النص فقط عندما تكون قيمة `isVisible` هي `true`
- استخدام العامل المنطقي `&&` للعرض الشرطي

## سلوك التطبيق

1. **عند فتح التطبيق**:
   - الزر يعرض "Show"
   - النص مخفي

2. **عند الضغط على الزر للمرة الأولى**:
   - النص يظهر
   - نص الزر يتغير إلى "Hide"

3. **عند الضغط على الزر مرة أخرى**:
   - النص يختفي
   - نص الزر يرجع إلى "Show"

## التخصيص

يمكنك تخصيص المكون بتغيير:

1. **النص المعروض**: استبدل `"Your Name Here"` باسمك الفعلي
2. **نصوص الزر**: يمكنك تغيير "Show" و "Hide" إلى أي نصوص أخرى
3. **الأنماط**: قم بتعديل `styles` لتغيير المظهر

## ما تعلمته من Task 17

### 1. **Dynamic UI Updates**
- كيفية تغيير محتوى UI بناءً على الـ state
- استخدام دوال لحساب قيم ديناميكية

### 2. **Ternary Operator**
```javascript
condition ? valueIfTrue : valueIfFalse
```
- طريقة مختصرة للـ if-else
- مفيدة جداً في JSX

### 3. **Better State Management**
- استخدام state واحد للتحكم في عدة عناصر UI
- تقليل التعقيد بدلاً من استخدام states متعددة

### 4. **Separation of Concerns**
- فصل منطق تحديد نص الزر في دالة منفصلة
- الكود أكثر وضوحاً وسهولة في الصيانة

## المصادر

- [React Native Button Documentation](https://reactnative.dev/docs/button)
- [React Native Conditional Rendering](https://reactnative.dev/docs/intro-react#conditional-rendering)
- [React Hooks - useState](https://react.dev/reference/react/useState)
- [JavaScript Ternary Operator](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Conditional_Operator)

## ملاحظات

- تم اتباع Guidelines المطلوبة:
  - ✅ إنشاء دالة منفصلة لكل عملية
  - ✅ عدم استخدام arrow functions كـ arguments
  - ✅ استخدام functional component
  - ✅ إدارة الحالة باستخدام React Hooks
  - ✅ كود نظيف وسهل القراءة

