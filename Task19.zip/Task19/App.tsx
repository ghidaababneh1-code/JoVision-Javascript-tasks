import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import Task19 from './Tasks/Task19';

function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Task19 />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default App;

