# Task 19 - Class Component with Show/Hide

## الوصف

هذا المكون يحقق متطلبات Task 19 من مهام JoVision React Native. يقوم بإنشاء تطبيق React Native يحتوي على زر لإظهار/إخفاء مكون Class Component مخصص.

## المتطلبات

- **زر بعنوان "Show"**: يتم عرض زر في البداية
- **Class Component مخصص**: مكون اسمه `MyClassPage` مبني بـ Class Component
- **Toggle Functionality**: عند الضغط على الزر، يظهر المكون المخصص ويختفي الزر

## التقنيات المستخدمة

- **Functional Component**: للمكون الرئيسي (Task19)
- **Class Component**: للمكون المخصص (MyClassPage)
- **React Hooks**: `useState` لإدارة حالة الظهور
- **Component Composition**: تركيب المكونات داخل بعضها
- **Conditional Rendering**: عرض مكونات مختلفة بناءً على الحالة

## هيكل الملفات

```
Tasks/
├── Task19.js          (المكون الرئيسي - Functional Component)
└── MyClassPage.js     (المكون المخصص - Class Component)
```

## الكود

### 1. MyClassPage.js (Class Component)

```javascript
import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';

class MyClassPage extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>MyClassPage</Text>
        <Text style={styles.description}>
          This is a custom class component!
        </Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  description: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
});

export default MyClassPage;
```

### 2. Task19.js (المكون الرئيسي)

```javascript
import React, { useState } from 'react';
import { View, Button, StyleSheet } from 'react-native';
import MyClassPage from './MyClassPage';

function Task19() {
  const [isVisible, setIsVisible] = useState(false);

  function handleButtonPress() {
    setIsVisible(!isVisible);
  }

  return (
    <View style={styles.container}>
      {!isVisible && (
        <View style={styles.buttonContainer}>
          <Button title="Show" onPress={handleButtonPress} />
        </View>
      )}
      {isVisible && <MyClassPage />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  buttonContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default Task19;
```

## كيفية الاستخدام

### 1. إضافة الملفات إلى مشروعك

قم بنسخ الملفات إلى مجلد `Tasks` في مشروع React Native الخاص بك:

```
YourReactNativeProject/
  ├── Tasks/
  │   ├── Task16.js
  │   ├── Task17.js
  │   ├── Task18.js
  │   ├── Task19.js
  │   └── MyClassPage.js
  └── App.tsx
```

### 2. استيراد المكون في App.tsx

في ملف `App.tsx` الرئيسي، قم باستيراد المكون واستخدامه:

```typescript
import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import Task19 from './Tasks/Task19';

function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Task19 />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default App;
```

### 3. تشغيل التطبيق

قم بتشغيل التطبيق باستخدام الأوامر التالية:

**لنظام Android:**
```bash
npx react-native run-android
```

**لنظام iOS:**
```bash
npx react-native run-ios
```

## شرح الكود بالتفصيل

### Class Component vs Functional Component

#### Functional Component (Task19.js)
```javascript
function Task19() {
  const [isVisible, setIsVisible] = useState(false);
  // ...
  return <View>...</View>;
}
```

#### Class Component (MyClassPage.js)
```javascript
class MyClassPage extends Component {
  render() {
    return <View>...</View>;
  }
}
```

### الفروقات الرئيسية

| Feature | Functional Component | Class Component |
|---------|---------------------|-----------------|
| **التعريف** | `function` أو `const` | `class extends Component` |
| **State** | `useState` hook | `this.state` |
| **Lifecycle** | `useEffect` hook | `componentDidMount`, etc. |
| **this** | ❌ لا يوجد | ✅ يستخدم `this` |
| **Syntax** | أبسط وأقصر | أطول وأكثر تعقيداً |
| **Performance** | أفضل قليلاً | جيد |
| **Modern** | ✅ الطريقة الحديثة | ⚠️ الطريقة القديمة |

### Class Component Structure

```javascript
class MyClassPage extends Component {
  // 1. Constructor (optional)
  constructor(props) {
    super(props);
    this.state = { ... };
  }

  // 2. Lifecycle methods (optional)
  componentDidMount() { ... }
  componentWillUnmount() { ... }

  // 3. Custom methods
  handleSomething() { ... }

  // 4. Render method (required)
  render() {
    return <View>...</View>;
  }
}
```

### Import Statement للـ Class Component

```javascript
import React, { Component } from 'react';
```

- يجب استيراد `Component` من `react`
- يتم الـ extend من `Component`

### Conditional Rendering في Task19

```javascript
{!isVisible && (
  <View style={styles.buttonContainer}>
    <Button title="Show" onPress={handleButtonPress} />
  </View>
)}
{isVisible && <MyClassPage />}
```

- عندما `isVisible === false`: يظهر الزر
- عندما `isVisible === true`: يظهر MyClassPage

## سلوك التطبيق

### المرحلة 1: عند فتح التطبيق
- ✅ يظهر زر "Show" في منتصف الشاشة
- ❌ MyClassPage مخفي

### المرحلة 2: عند الضغط على الزر
- ❌ الزر يختفي
- ✅ MyClassPage يظهر بكامل الشاشة

### المرحلة 3: عند الضغط على الشاشة (في Task 20)
- سيتم إضافة وظيفة للرجوع

## ما تعلمته من Task 19

### 1. **Class Components**
```javascript
class MyClassPage extends Component {
  render() {
    return <View>...</View>;
  }
}
```
- الطريقة التقليدية لبناء المكونات
- مهم لفهم الكود القديم
- أساس لفهم Lifecycle methods

### 2. **Component Composition**
```javascript
import MyClassPage from './MyClassPage';
// ...
{isVisible && <MyClassPage />}
```
- كيفية استخدام مكون داخل مكون آخر
- بناء تطبيقات معقدة من مكونات صغيرة

### 3. **Component vs Element**
- **Component**: التعريف (الـ class أو الـ function)
- **Element**: الاستخدام (`<MyClassPage />`)

### 4. **Import/Export**
```javascript
// MyClassPage.js
export default MyClassPage;

// Task19.js
import MyClassPage from './MyClassPage';
```
- تنظيم الكود في ملفات منفصلة
- إعادة استخدام المكونات

### 5. **Separate Files Best Practice**
- كل مكون في ملف منفصل
- سهولة الصيانة والتطوير
- إعادة الاستخدام في أماكن متعددة

## متى تستخدم Class Components؟

### ✅ استخدم Class Components عندما:
- تعمل على مشروع قديم يستخدمها
- تحتاج لفهم كود موجود
- تتعلم React Native من الأساس

### ❌ لا تستخدم Class Components في:
- المشاريع الجديدة (استخدم Functional Components)
- الكود الحديث (Hooks أفضل)
- التطبيقات البسيطة

## Class Component Lifecycle (نظرة سريعة)

سنتعلمها بالتفصيل في Task 20:

```javascript
class MyClassPage extends Component {
  componentDidMount() {
    // يتم تشغيله عند ظهور المكون
    console.log('Component loaded');
  }

  componentWillUnmount() {
    // يتم تشغيله عند إخفاء المكون
    console.log('Component unloaded');
  }

  render() {
    return <View>...</View>;
  }
}
```

## المصادر

- [Functional vs Class Components](https://www.freecodecamp.org/news/functional-vs-class-components-react-native/)
- [React Class Components](https://react.dev/reference/react/Component)
- [React Native Components](https://reactnative.dev/docs/intro-react#custom-components)

## مقارنة بين المهام

| Feature | Task 16-18 | Task 19 |
|---------|-----------|---------|
| **Component Type** | Functional فقط | Functional + Class |
| **Files** | ملف واحد | ملفين منفصلين |
| **Complexity** | بسيط | متوسط |
| **New Concepts** | Hooks | Class Components |
| **Import/Export** | ❌ | ✅ |

## ملاحظات

- تم اتباع Guidelines المطلوبة:
  - ✅ إنشاء دوال منفصلة لكل عملية
  - ✅ عدم استخدام arrow functions كـ arguments
  - ✅ إنشاء Class Component مخصص
  - ✅ فصل المكونات في ملفات منفصلة
  - ✅ كود نظيف ومنظم
  - ✅ استخدام import/export بشكل صحيح

## الخطوة التالية

في **Task 20** سنضيف:
- `componentDidMount()` - عند ظهور المكون
- `componentWillUnmount()` - عند إخفاء المكون
- Console logging لتتبع الـ lifecycle

