import React, { useState } from 'react';
import { View, Button, StyleSheet } from 'react-native';
import MyClassPage from './MyClassPage';

function Task19() {
  const [isVisible, setIsVisible] = useState(false);

  function handleButtonPress() {
    setIsVisible(!isVisible);
  }

  return (
    <View style={styles.container}>
      {!isVisible && (
        <View style={styles.buttonContainer}>
          <Button title="Show" onPress={handleButtonPress} />
        </View>
      )}
      {isVisible && <MyClassPage />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  buttonContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default Task19;

