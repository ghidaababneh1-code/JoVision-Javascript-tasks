# Task 20 - Class Component Lifecycle Methods

## الوصف

هذا المكون يحقق متطلبات Task 20 من مهام JoVision React Native. يقوم بإنشاء تطبيق React Native يحتوي على Class Component مع Lifecycle Methods لتتبع متى يتم تحميل وإلغاء تحميل المكون.

## المتطلبات

- **زر بعنوان "Show"**: يتم عرض زر في البداية
- **Class Component مخصص**: مكون اسمه `MyClassPage` مبني بـ Class Component
- **Toggle Functionality**: عند الضغط على الزر، يظهر/يختفي المكون
- **componentDidMount**: عند ظهور المكون، طباعة "Component loaded" في الـ console
- **componentWillUnmount**: عند إخفاء المكون، طباعة "Component unloaded" في الـ console

## التقنيات المستخدمة

- **Class Component**: للمكون المخصص (MyClassPage)
- **Lifecycle Methods**:
  - `componentDidMount()` - يتم تشغيله عند ظهور المكون
  - `componentWillUnmount()` - يتم تشغيله عند إخفاء المكون
- **Console Logging**: لتتبع دورة حياة المكون
- **React Hooks**: `useState` للمكون الرئيسي

## هيكل الملفات

```
Tasks/
├── Task20.js          (المكون الرئيسي - Functional Component)
└── MyClassPage.js     (المكون المخصص - Class Component with Lifecycle)
```

## الكود

### 1. MyClassPage.js (Class Component with Lifecycle)

```javascript
import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';

class MyClassPage extends Component {
  componentDidMount() {
    console.log('Component loaded');
  }

  componentWillUnmount() {
    console.log('Component unloaded');
  }

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>MyClassPage</Text>
        <Text style={styles.description}>
          This is a custom class component with lifecycle methods!
        </Text>
        <Text style={styles.info}>
          Check the console to see lifecycle logs.
        </Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  description: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 20,
  },
  info: {
    fontSize: 14,
    color: '#999',
    fontStyle: 'italic',
    textAlign: 'center',
  },
});

export default MyClassPage;
```

### 2. Task20.js (المكون الرئيسي)

```javascript
import React, { useState } from 'react';
import { View, Button, StyleSheet } from 'react-native';
import MyClassPage from './MyClassPage';

function Task20() {
  const [isVisible, setIsVisible] = useState(false);

  function handleButtonPress() {
    setIsVisible(!isVisible);
  }

  function getButtonTitle() {
    return isVisible ? 'Hide' : 'Show';
  }

  return (
    <View style={styles.container}>
      {!isVisible && (
        <View style={styles.buttonContainer}>
          <Button title={getButtonTitle()} onPress={handleButtonPress} />
        </View>
      )}
      {isVisible && <MyClassPage />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  buttonContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default Task20;
```

## كيفية الاستخدام

### 1. إضافة الملفات إلى مشروعك

قم بنسخ الملفات إلى مجلد `Tasks` في مشروع React Native الخاص بك:

```
YourReactNativeProject/
  ├── Tasks/
  │   ├── Task16.js
  │   ├── Task17.js
  │   ├── Task18.js
  │   ├── Task19.js
  │   ├── Task20.js
  │   └── MyClassPage.js
  └── App.tsx
```

### 2. استيراد المكون في App.tsx

في ملف `App.tsx` الرئيسي، قم باستيراد المكون واستخدامه:

```typescript
import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import Task20 from './Tasks/Task20';

function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Task20 />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default App;
```

### 3. تشغيل التطبيق

قم بتشغيل التطبيق باستخدام الأوامر التالية:

**لنظام Android:**
```bash
npx react-native run-android
```

**لنظام iOS:**
```bash
npx react-native run-ios
```

### 4. فتح Console لرؤية الـ Logs

**في React Native:**
- افتح Terminal جديد
- شغل الأمر: `npx react-native log-android` (لـ Android)
- أو: `npx react-native log-ios` (لـ iOS)

**في Chrome DevTools:**
- اضغط `Ctrl+M` (Android) أو `Cmd+D` (iOS)
- اختر "Debug"
- افتح Chrome DevTools (F12)
- اذهب إلى تبويب Console

## شرح الكود بالتفصيل

### Class Component Lifecycle Methods

```javascript
class MyClassPage extends Component {
  componentDidMount() {
    console.log('Component loaded');
  }

  componentWillUnmount() {
    console.log('Component unloaded');
  }

  render() {
    return <View>...</View>;
  }
}
```

### 1. componentDidMount()

```javascript
componentDidMount() {
  console.log('Component loaded');
}
```

- **متى يتم تشغيله؟** مباشرة بعد ظهور المكون على الشاشة
- **يستخدم لـ:**
  - تحميل البيانات من API
  - إعداد Subscriptions
  - بدء Timers
  - تهيئة المكون

### 2. componentWillUnmount()

```javascript
componentWillUnmount() {
  console.log('Component unloaded');
}
```

- **متى يتم تشغيله؟** مباشرة قبل إزالة المكون من الشاشة
- **يستخدم لـ:**
  - تنظيف Timers
  - إلغاء Subscriptions
  - إلغاء Network Requests
  - منع Memory Leaks

### 3. render()

```javascript
render() {
  return <View>...</View>;
}
```

- **متى يتم تشغيله؟** في كل مرة يتم فيها تحديث المكون
- **يستخدم لـ:** عرض UI

## Component Lifecycle Flow

### عند الضغط على "Show":

```
1. Constructor (إذا كان موجود)
   ↓
2. render() - عرض المكون
   ↓
3. componentDidMount() - "Component loaded" 🟢
```

### عند الضغط على "Hide":

```
1. componentWillUnmount() - "Component unloaded" 🔴
   ↓
2. المكون يتم إزالته من الشاشة
```

## سلوك التطبيق

### المرحلة 1: عند فتح التطبيق
- ✅ يظهر زر "Show"
- ❌ MyClassPage مخفي
- 📝 Console: (لا شيء)

### المرحلة 2: عند الضغط على "Show"
- ❌ الزر يختفي
- ✅ MyClassPage يظهر
- 📝 Console: **"Component loaded"** 🟢

### المرحلة 3: عند الضغط على الشاشة (أو زر Hide)
- ✅ الزر يظهر مرة أخرى
- ❌ MyClassPage يختفي
- 📝 Console: **"Component unloaded"** 🔴

## Class Component Lifecycle Methods الكاملة

### Mounting (التحميل)
```javascript
constructor(props)          // 1. تهيئة State
↓
render()                    // 2. عرض UI
↓
componentDidMount()         // 3. بعد العرض (API calls, etc.)
```

### Updating (التحديث)
```javascript
render()                    // 1. إعادة عرض UI
↓
componentDidUpdate()        // 2. بعد التحديث
```

### Unmounting (الإزالة)
```javascript
componentWillUnmount()      // قبل الإزالة (cleanup)
```

## Lifecycle Methods vs Hooks

| Class Component | Functional Component (Hooks) |
|----------------|------------------------------|
| `componentDidMount()` | `useEffect(() => { ... }, [])` |
| `componentWillUnmount()` | `useEffect(() => { return () => { ... } }, [])` |
| `componentDidUpdate()` | `useEffect(() => { ... })` |

### مثال بـ useEffect (للمقارنة):

```javascript
function MyFunctionPage() {
  useEffect(() => {
    console.log('Component loaded');
    
    return () => {
      console.log('Component unloaded');
    };
  }, []);

  return <View>...</View>;
}
```

## ما تعلمته من Task 20

### 1. **componentDidMount()**
- أهم lifecycle method
- يستخدم لتحميل البيانات
- يتم تشغيله مرة واحدة فقط

### 2. **componentWillUnmount()**
- مهم جداً لتنظيف الموارد
- يمنع Memory Leaks
- يلغي العمليات الجارية

### 3. **Component Lifecycle**
- فهم دورة حياة المكون الكاملة
- متى يتم تحميل وإزالة المكونات
- كيفية تتبع حالة المكون

### 4. **Console Logging**
- أداة مهمة للـ Debugging
- تتبع سلوك التطبيق
- فهم ترتيب تنفيذ الكود

### 5. **Memory Management**
- أهمية تنظيف الموارد
- منع Memory Leaks
- Best practices في React Native

## حالات الاستخدام في التطبيقات الحقيقية

### componentDidMount:
- 📡 تحميل البيانات من API
- 🔔 الاشتراك في Notifications
- ⏱️ بدء Timers
- 🎵 تشغيل Audio/Video
- 📍 تتبع الموقع الجغرافي

### componentWillUnmount:
- 🛑 إيقاف Timers
- 🔕 إلغاء Subscriptions
- ❌ إلغاء Network Requests
- 🎵 إيقاف Audio/Video
- 🧹 تنظيف الموارد

## مثال عملي: Timer

```javascript
class TimerComponent extends Component {
  constructor(props) {
    super(props);
    this.state = { seconds: 0 };
  }

  componentDidMount() {
    this.timer = setInterval(() => {
      this.setState({ seconds: this.state.seconds + 1 });
    }, 1000);
    console.log('Timer started');
  }

  componentWillUnmount() {
    clearInterval(this.timer);
    console.log('Timer stopped');
  }

  render() {
    return <Text>{this.state.seconds} seconds</Text>;
  }
}
```

## ⚠️ Common Mistakes (أخطاء شائعة)

### ❌ نسيان Cleanup
```javascript
componentDidMount() {
  setInterval(() => { ... }, 1000);
  // ❌ لم يتم حفظ reference للـ interval
}
```

### ✅ الطريقة الصحيحة
```javascript
componentDidMount() {
  this.timer = setInterval(() => { ... }, 1000);
}

componentWillUnmount() {
  clearInterval(this.timer); // ✅ تنظيف
}
```

## المصادر

- [React Native Lifecycle](https://www.netguru.com/blog/react-native-lifecycle)
- [React Component Lifecycle](https://react.dev/reference/react/Component#componentdidmount)
- [React Native Debugging](https://reactnative.dev/docs/debugging)

## مقارنة بين المهام

| Feature | Task 19 | Task 20 |
|---------|---------|---------|
| **Class Component** | ✅ | ✅ |
| **Lifecycle Methods** | ❌ | ✅ componentDidMount, componentWillUnmount |
| **Console Logging** | ❌ | ✅ |
| **Complexity** | متوسط | متوسط-متقدم |

## ملاحظات

- تم اتباع Guidelines المطلوبة:
  - ✅ إنشاء Class Component مخصص
  - ✅ إضافة Lifecycle Methods
  - ✅ Console logging للتتبع
  - ✅ فصل المكونات في ملفات منفصلة
  - ✅ كود نظيف ومنظم
  - ✅ تنظيف الموارد بشكل صحيح

## الخطوة التالية

في **Task 21** سنتعلم:
- نفس الشيء لكن مع **Functional Component**
- استخدام `useEffect` hook
- المقارنة بين الطريقتين

