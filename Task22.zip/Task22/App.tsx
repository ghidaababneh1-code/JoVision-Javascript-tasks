import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import Task22 from './Tasks/Task22';

function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Task22 />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default App;

