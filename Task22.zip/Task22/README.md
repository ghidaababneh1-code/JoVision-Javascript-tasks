# Task 22 - Props and Child to Parent Communication

## الوصف

هذا المكون يحقق متطلبات Task 22 من مهام JoVision React Native. يقوم بإنشاء تطبيق React Native يوضح كيفية تمرير البيانات من المكون الابن (Child) إلى المكون الأب (Parent) باستخدام Props و Callback Functions.

## المتطلبات

- **Text Component في Parent**: لعرض النص المستلم من Child
- **TextInput في MyFunctionPage**: حقل إدخال نص في المكون الابن
- **Props**: تمرير callback function من Parent إلى Child
- **Real-time Update**: عند الكتابة في TextInput، يتم تحديث النص في Parent مباشرة

## التقنيات المستخدمة

- **Props**: تمرير البيانات والدوال بين المكونات
- **Callback Functions**: دوال يتم تمريرها كـ props
- **TextInput**: مكون لإدخال النص
- **useState**: لإدارة حالة النص في Parent
- **onChangeText**: حدث يتم تشغيله عند تغيير النص

## هيكل الملفات

```
Tasks/
├── Task22.js           (المكون الرئيسي - Parent)
└── MyFunctionPage.js   (المكون الابن - Child with TextInput)
```

## الكود

### 1. MyFunctionPage.js (Child Component)

```javascript
import React from 'react';
import { View, TextInput, Text, StyleSheet } from 'react-native';

function MyFunctionPage(props) {
  function handleTextChange(text) {
    props.onTextChange(text);
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>MyFunctionPage</Text>
      <Text style={styles.label}>Enter text below:</Text>
      <TextInput
        style={styles.input}
        placeholder="Type something..."
        onChangeText={handleTextChange}
      />
      <Text style={styles.info}>
        The text you type will appear in the parent component!
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#e3f2fd',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1565c0',
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    color: '#1976d2',
    marginBottom: 10,
  },
  input: {
    width: '100%',
    height: 50,
    borderWidth: 2,
    borderColor: '#42a5f5',
    borderRadius: 8,
    paddingHorizontal: 15,
    fontSize: 16,
    backgroundColor: '#fff',
    marginBottom: 20,
  },
  info: {
    fontSize: 14,
    color: '#64b5f6',
    fontStyle: 'italic',
    textAlign: 'center',
  },
});

export default MyFunctionPage;
```

### 2. Task22.js (Parent Component)

```javascript
import React, { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import MyFunctionPage from './MyFunctionPage';

function Task22() {
  const [textFromChild, setTextFromChild] = useState('');

  function handleTextUpdate(newText) {
    setTextFromChild(newText);
  }

  return (
    <View style={styles.container}>
      <View style={styles.parentSection}>
        <Text style={styles.parentTitle}>Parent Component</Text>
        <Text style={styles.label}>Text from child:</Text>
        <View style={styles.textDisplay}>
          <Text style={styles.displayedText}>
            {textFromChild || 'No text yet...'}
          </Text>
        </View>
      </View>
      <MyFunctionPage onTextChange={handleTextUpdate} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  parentSection: {
    padding: 20,
    backgroundColor: '#f5f5f5',
    borderBottomWidth: 2,
    borderBottomColor: '#e0e0e0',
  },
  parentTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  label: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  textDisplay: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    minHeight: 50,
  },
  displayedText: {
    fontSize: 16,
    color: '#333',
  },
});

export default Task22;
```

## كيفية الاستخدام

### 1. إضافة الملفات إلى مشروعك

قم بنسخ الملفات إلى مجلد `Tasks` في مشروع React Native الخاص بك:

```
YourReactNativeProject/
  ├── Tasks/
  │   ├── Task22.js
  │   └── MyFunctionPage.js
  └── App.tsx
```

### 2. استيراد المكون في App.tsx

```typescript
import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import Task22 from './Tasks/Task22';

function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Task22 />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default App;
```

### 3. تشغيل التطبيق

```bash
npx react-native run-android  # لـ Android
npx react-native run-ios       # لـ iOS
```

## شرح الكود بالتفصيل

### Data Flow (تدفق البيانات)

```
┌─────────────────────────────────────┐
│      Parent (Task22)                │
│                                     │
│  1. State: textFromChild            │
│  2. Function: handleTextUpdate()    │
│  3. Pass function as prop ↓         │
└─────────────────────────────────────┘
                  │
                  │ onTextChange={handleTextUpdate}
                  ↓
┌─────────────────────────────────────┐
│      Child (MyFunctionPage)         │
│                                     │
│  1. Receive: props.onTextChange     │
│  2. User types in TextInput         │
│  3. Call: props.onTextChange(text)  │
└─────────────────────────────────────┘
                  │
                  │ text data
                  ↓
┌─────────────────────────────────────┐
│      Parent (Task22)                │
│                                     │
│  4. handleTextUpdate() receives text│
│  5. setTextFromChild(text)          │
│  6. Re-render with new text         │
└─────────────────────────────────────┘
```

### 1. Parent Component (Task22)

#### State Management
```javascript
const [textFromChild, setTextFromChild] = useState('');
```
- يحفظ النص المستلم من Child

#### Callback Function
```javascript
function handleTextUpdate(newText) {
  setTextFromChild(newText);
}
```
- يتم استدعاؤها من Child
- تحدث الـ state بالنص الجديد

#### Passing Props
```javascript
<MyFunctionPage onTextChange={handleTextUpdate} />
```
- تمرير الدالة `handleTextUpdate` كـ prop
- اسم الـ prop: `onTextChange`

#### Displaying Data
```javascript
<Text>{textFromChild || 'No text yet...'}</Text>
```
- عرض النص المستلم
- إذا كان فارغاً، عرض رسالة افتراضية

### 2. Child Component (MyFunctionPage)

#### Receiving Props
```javascript
function MyFunctionPage(props) {
  // props.onTextChange is available here
}
```
- استقبال الـ props من Parent
- `props.onTextChange` هي الدالة المُمررة

#### TextInput Component
```javascript
<TextInput
  style={styles.input}
  placeholder="Type something..."
  onChangeText={handleTextChange}
/>
```
- **placeholder**: نص توضيحي
- **onChangeText**: يتم تشغيله عند كل تغيير في النص

#### Handling Text Change
```javascript
function handleTextChange(text) {
  props.onTextChange(text);
}
```
- دالة منفصلة (Best Practice)
- تستدعي الدالة المُمررة من Parent
- تمرر النص الجديد

## Props في React Native

### ما هي Props؟

**Props** (اختصار لـ Properties) هي طريقة لتمرير البيانات من مكون إلى آخر.

### أنواع Props

#### 1. Data Props (تمرير بيانات)
```javascript
<MyComponent name="Ahmed" age={25} />
```

#### 2. Function Props (تمرير دوال)
```javascript
<MyComponent onPress={handlePress} />
```

#### 3. Component Props (تمرير مكونات)
```javascript
<MyComponent icon={<Icon />} />
```

### Props في Task 22

```javascript
// Parent
<MyFunctionPage onTextChange={handleTextUpdate} />

// Child
function MyFunctionPage(props) {
  props.onTextChange('Hello');
}
```

## Child to Parent Communication

### الطريقة الصحيحة:

```javascript
// Parent
function Parent() {
  const [data, setData] = useState('');
  
  function handleDataFromChild(newData) {
    setData(newData);
  }
  
  return <Child onDataChange={handleDataFromChild} />;
}

// Child
function Child(props) {
  function sendDataToParent() {
    props.onDataChange('Hello from child!');
  }
  
  return <Button onPress={sendDataToParent} />;
}
```

### ❌ الطريقة الخاطئة:

```javascript
// Child cannot directly access parent's state
// Child cannot call parent's setState directly
```

## TextInput Component

### الخصائص الأساسية:

```javascript
<TextInput
  value={text}                    // القيمة الحالية
  onChangeText={handleChange}     // عند تغيير النص
  placeholder="Enter text..."     // نص توضيحي
  style={styles.input}            // التنسيق
  keyboardType="default"          // نوع الكيبورد
  autoCapitalize="none"           // تحويل الأحرف
  secureTextEntry={false}         // لكلمات المرور
  multiline={false}               // عدة أسطر
  maxLength={100}                 // الحد الأقصى
/>
```

### onChangeText vs onChange

```javascript
// ✅ Recommended
onChangeText={(text) => console.log(text)}

// ❌ Less common
onChange={(event) => console.log(event.nativeEvent.text)}
```

## سلوك التطبيق

### المرحلة 1: عند فتح التطبيق
- ✅ Parent يعرض "No text yet..."
- ✅ Child يعرض TextInput فارغ

### المرحلة 2: عند الكتابة في TextInput
1. المستخدم يكتب "H"
2. `onChangeText` يتم تشغيله
3. `handleTextChange("H")` يتم استدعاؤه
4. `props.onTextChange("H")` يتم استدعاؤه
5. `handleTextUpdate("H")` في Parent يتم تشغيله
6. `setTextFromChild("H")` يحدث الـ state
7. Parent يعيد الـ render
8. النص "H" يظهر في Parent

### المرحلة 3: الكتابة المستمرة
- كل حرف يتم كتابته يُحدث نفس العملية
- التحديث فوري (Real-time)

## ما تعلمته من Task 22

### 1. **Props**
- كيفية تمرير البيانات بين المكونات
- Props هي read-only (لا يمكن تعديلها)

### 2. **Callback Functions**
- تمرير دوال كـ props
- استدعاء دوال Parent من Child

### 3. **Child to Parent Communication**
- الطريقة الصحيحة لتمرير البيانات من Child إلى Parent
- استخدام callback functions

### 4. **TextInput**
- كيفية استخدام حقول الإدخال
- معالجة تغييرات النص

### 5. **Real-time Updates**
- تحديث UI فوري
- Reactive programming

### 6. **Component Communication**
- كيفية تواصل المكونات مع بعضها
- Data flow في React Native

## أنماط Props الشائعة

### Pattern 1: Data Props
```javascript
<Child name="Ahmed" age={25} />

function Child(props) {
  return <Text>{props.name} is {props.age}</Text>;
}
```

### Pattern 2: Function Props
```javascript
<Child onPress={handlePress} />

function Child(props) {
  return <Button onPress={props.onPress} />;
}
```

### Pattern 3: Destructuring Props
```javascript
function Child({ name, age, onPress }) {
  return <Button title={name} onPress={onPress} />;
}
```

### Pattern 4: Default Props
```javascript
function Child({ name = 'Guest' }) {
  return <Text>Hello {name}</Text>;
}
```

## Best Practices

### ✅ Do:
```javascript
// دوال منفصلة
function handleTextChange(text) {
  props.onTextChange(text);
}

// أسماء واضحة للـ props
<Child onTextChange={handleUpdate} />

// Destructuring
function Child({ onTextChange }) { ... }
```

### ❌ Don't:
```javascript
// Arrow functions مباشرة
<TextInput onChangeText={(text) => props.onTextChange(text)} />

// أسماء غير واضحة
<Child func={handleUpdate} />

// تعديل props
props.value = 'new'; // ❌ Props are read-only
```

## المصادر

- [React Native Props](https://reactnative.dev/docs/props)
- [React Native TextInput](https://reactnative.dev/docs/textinput)
- [React Component Communication](https://react.dev/learn/passing-props-to-a-component)

## مقارنة بين المهام

| Task | Concept | Communication | Complexity |
|------|---------|--------------|-----------|
| **19** | Class Component | ❌ | ⭐⭐ |
| **20** | Class Lifecycle | ❌ | ⭐⭐⭐ |
| **21** | Functional Lifecycle | ❌ | ⭐⭐⭐ |
| **22** | Props & Communication | ✅ Child → Parent | ⭐⭐⭐ |

## ملاحظات

- تم اتباع Guidelines المطلوبة:
  - ✅ إنشاء دوال منفصلة
  - ✅ عدم استخدام arrow functions كـ arguments
  - ✅ استخدام Props بشكل صحيح
  - ✅ Child to Parent communication
  - ✅ TextInput implementation
  - ✅ Real-time updates
  - ✅ كود نظيف ومنظم

## الخطوة التالية

في **Task 23** سنتعلم:
- نفس الشيء لكن مع **Class Component**
- استخدام `this.props` بدلاً من `props`
- المقارنة بين الطريقتين

