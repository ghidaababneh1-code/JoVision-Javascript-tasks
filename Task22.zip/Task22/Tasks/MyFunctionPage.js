import React from 'react';
import { View, TextInput, Text, StyleSheet } from 'react-native';

function MyFunctionPage(props) {
  function handleTextChange(text) {
    props.onTextChange(text);
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>MyFunctionPage</Text>
      <Text style={styles.label}>Enter text below:</Text>
      <TextInput
        style={styles.input}
        placeholder="Type something..."
        onChangeText={handleTextChange}
      />
      <Text style={styles.info}>
        The text you type will appear in the parent component!
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#e3f2fd',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1565c0',
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    color: '#1976d2',
    marginBottom: 10,
  },
  input: {
    width: '100%',
    height: 50,
    borderWidth: 2,
    borderColor: '#42a5f5',
    borderRadius: 8,
    paddingHorizontal: 15,
    fontSize: 16,
    backgroundColor: '#fff',
    marginBottom: 20,
  },
  info: {
    fontSize: 14,
    color: '#64b5f6',
    fontStyle: 'italic',
    textAlign: 'center',
  },
});

export default MyFunctionPage;

