import React, { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import MyFunctionPage from './MyFunctionPage';

function Task22() {
  const [textFromChild, setTextFromChild] = useState('');

  function handleTextUpdate(newText) {
    setTextFromChild(newText);
  }

  return (
    <View style={styles.container}>
      <View style={styles.parentSection}>
        <Text style={styles.parentTitle}>Parent Component</Text>
        <Text style={styles.label}>Text from child:</Text>
        <View style={styles.textDisplay}>
          <Text style={styles.displayedText}>
            {textFromChild || 'No text yet...'}
          </Text>
        </View>
      </View>
      <MyFunctionPage onTextChange={handleTextUpdate} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  parentSection: {
    padding: 20,
    backgroundColor: '#f5f5f5',
    borderBottomWidth: 2,
    borderBottomColor: '#e0e0e0',
  },
  parentTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  label: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  textDisplay: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    minHeight: 50,
  },
  displayedText: {
    fontSize: 16,
    color: '#333',
  },
});

export default Task22;

