# Task 23 - Props with Class Components

## الوصف

هذا المكون يحقق متطلبات Task 23 من مهام JoVision React Native. يقوم بتكرار Task 22 ولكن باستخدام **Class Components** بدلاً من Functional Components، لتوضيح الفرق بين الطريقتين في التعامل مع Props.

## المتطلبات

- **Text Component في Parent**: لعرض النص المستلم من Child
- **TextInput في MyClassPage**: حقل إدخال نص في المكون الابن (Class Component)
- **Props مع Class Components**: تمرير callback function باستخدام `this.props`
- **Child to Parent Communication**: تمرير البيانات من Class Child إلى Class Parent

## التقنيات المستخدمة

- **Class Components**: للـ Parent والـ Child
- **this.props**: للوصول إلى Props في Class Components
- **this.state**: لإدارة الحالة في Class Components
- **this.setState()**: لتحديث الحالة
- **Constructor**: لتهيئة الـ state
- **TextInput**: مكون لإدخال النص

## هيكل الملفات

```
Tasks/
├── Task23.js          (المكون الرئيسي - Parent Class Component)
└── MyClassPage.js     (المكون الابن - Child Class Component with TextInput)
```

## الكود

### 1. MyClassPage.js (Child Class Component)

```javascript
import React, { Component } from 'react';
import { View, TextInput, Text, StyleSheet } from 'react-native';

class MyClassPage extends Component {
  handleTextChange(text) {
    this.props.onTextChange(text);
  }

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>MyClassPage</Text>
        <Text style={styles.label}>Enter text below:</Text>
        <TextInput
          style={styles.input}
          placeholder="Type something..."
          onChangeText={(text) => this.handleTextChange(text)}
        />
        <Text style={styles.info}>
          The text you type will appear in the parent component!
        </Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fce4ec',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#c2185b',
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    color: '#d81b60',
    marginBottom: 10,
  },
  input: {
    width: '100%',
    height: 50,
    borderWidth: 2,
    borderColor: '#f06292',
    borderRadius: 8,
    paddingHorizontal: 15,
    fontSize: 16,
    backgroundColor: '#fff',
    marginBottom: 20,
  },
  info: {
    fontSize: 14,
    color: '#f48fb1',
    fontStyle: 'italic',
    textAlign: 'center',
  },
});

export default MyClassPage;
```

### 2. Task23.js (Parent Class Component)

```javascript
import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import MyClassPage from './MyClassPage';

class Task23 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      textFromChild: '',
    };
  }

  handleTextUpdate(newText) {
    this.setState({ textFromChild: newText });
  }

  render() {
    return (
      <View style={styles.container}>
        <View style={styles.parentSection}>
          <Text style={styles.parentTitle}>Parent Component (Class)</Text>
          <Text style={styles.label}>Text from child:</Text>
          <View style={styles.textDisplay}>
            <Text style={styles.displayedText}>
              {this.state.textFromChild || 'No text yet...'}
            </Text>
          </View>
        </View>
        <MyClassPage onTextChange={(text) => this.handleTextUpdate(text)} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  parentSection: {
    padding: 20,
    backgroundColor: '#f5f5f5',
    borderBottomWidth: 2,
    borderBottomColor: '#e0e0e0',
  },
  parentTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  label: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  textDisplay: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    minHeight: 50,
  },
  displayedText: {
    fontSize: 16,
    color: '#333',
  },
});

export default Task23;
```

## شرح الكود بالتفصيل

### Task 22 (Functional) vs Task 23 (Class)

#### Parent Component

**Task 22 (Functional):**
```javascript
function Task22() {
  const [textFromChild, setTextFromChild] = useState('');

  function handleTextUpdate(newText) {
    setTextFromChild(newText);
  }

  return (
    <MyFunctionPage onTextChange={handleTextUpdate} />
  );
}
```

**Task 23 (Class):**
```javascript
class Task23 extends Component {
  constructor(props) {
    super(props);
    this.state = { textFromChild: '' };
  }

  handleTextUpdate(newText) {
    this.setState({ textFromChild: newText });
  }

  render() {
    return (
      <MyClassPage onTextChange={(text) => this.handleTextUpdate(text)} />
    );
  }
}
```

#### Child Component

**Task 22 (Functional):**
```javascript
function MyFunctionPage(props) {
  function handleTextChange(text) {
    props.onTextChange(text);
  }

  return <TextInput onChangeText={handleTextChange} />;
}
```

**Task 23 (Class):**
```javascript
class MyClassPage extends Component {
  handleTextChange(text) {
    this.props.onTextChange(text);
  }

  render() {
    return <TextInput onChangeText={(text) => this.handleTextChange(text)} />;
  }
}
```

## الفروقات الرئيسية

### 1. State Management

| Functional (Task 22) | Class (Task 23) |
|---------------------|-----------------|
| `const [state, setState] = useState('')` | `this.state = { ... }` |
| `setState(newValue)` | `this.setState({ ... })` |
| لا يحتاج constructor | يحتاج constructor |

### 2. Props Access

| Functional (Task 22) | Class (Task 23) |
|---------------------|-----------------|
| `props.onTextChange` | `this.props.onTextChange` |
| يتم تمريره كـ parameter | يتم الوصول إليه عبر `this` |

### 3. Methods

| Functional (Task 22) | Class (Task 23) |
|---------------------|-----------------|
| `function handleUpdate() { ... }` | `handleUpdate() { ... }` |
| دوال عادية | methods في الـ class |

### 4. Render

| Functional (Task 22) | Class (Task 23) |
|---------------------|-----------------|
| `return <View>...</View>` | `render() { return <View>...</View> }` |
| مباشر | داخل method اسمه render |

## Class Component Structure

```javascript
class MyComponent extends Component {
  // 1. Constructor (تهيئة State)
  constructor(props) {
    super(props);
    this.state = { ... };
  }

  // 2. Lifecycle Methods
  componentDidMount() { ... }
  componentWillUnmount() { ... }

  // 3. Custom Methods
  handleSomething() { ... }

  // 4. Render Method (required)
  render() {
    return <View>...</View>;
  }
}
```

## Props في Class Components

### Accessing Props

```javascript
class MyComponent extends Component {
  render() {
    // ✅ الطريقة الصحيحة
    return <Text>{this.props.name}</Text>;
    
    // ❌ خطأ - لا يوجد props مباشرة
    // return <Text>{props.name}</Text>;
  }
}
```

### Passing Props

```javascript
class Parent extends Component {
  render() {
    return <Child name="Ahmed" onPress={this.handlePress} />;
  }
}
```

### Using Props in Methods

```javascript
class MyComponent extends Component {
  handleClick() {
    // استخدام this.props في methods
    this.props.onPress(this.props.data);
  }

  render() {
    return <Button onPress={() => this.handleClick()} />;
  }
}
```

## State في Class Components

### Initializing State

```javascript
constructor(props) {
  super(props);  // ⚠️ مهم جداً
  this.state = {
    text: '',
    count: 0,
  };
}
```

### Updating State

```javascript
// ✅ الطريقة الصحيحة
this.setState({ text: 'new value' });

// ❌ خطأ - لا تعدل state مباشرة
this.state.text = 'new value';
```

### Reading State

```javascript
render() {
  return <Text>{this.state.text}</Text>;
}
```

## this في Class Components

### ما هو this؟

`this` يشير إلى instance الـ class الحالي.

```javascript
class MyComponent extends Component {
  constructor(props) {
    super(props);
    this.state = { ... };  // this = instance الحالي
  }

  handleClick() {
    this.setState({ ... });  // this = instance الحالي
    this.props.onPress();     // this = instance الحالي
  }
}
```

### ⚠️ this Binding Problem

```javascript
// ❌ مشكلة - this قد يكون undefined
<Button onPress={this.handleClick} />

// ✅ الحل 1: Arrow function
<Button onPress={() => this.handleClick()} />

// ✅ الحل 2: Bind في constructor
constructor(props) {
  super(props);
  this.handleClick = this.handleClick.bind(this);
}

// ✅ الحل 3: Arrow function method
handleClick = () => {
  this.setState({ ... });
}
```

## Data Flow في Task 23

```
┌──────────────────────────────────┐
│  Parent (Task23 - Class)         │
│                                  │
│  1. State: this.state.textFromChild│
│  2. Method: handleTextUpdate()   │
│  3. Pass as prop ↓               │
└──────────────────────────────────┘
            │
            │ onTextChange={(text) => this.handleTextUpdate(text)}
            ↓
┌──────────────────────────────────┐
│  Child (MyClassPage - Class)     │
│                                  │
│  1. Receive: this.props.onTextChange│
│  2. User types in TextInput      │
│  3. Call: this.props.onTextChange()│
└──────────────────────────────────┘
            │
            │ text data
            ↓
┌──────────────────────────────────┐
│  Parent (Task23)                 │
│                                  │
│  4. handleTextUpdate() called    │
│  5. this.setState({ ... })       │
│  6. Re-render                    │
│  7. Show new text                │
└──────────────────────────────────┘
```

## ما تعلمته من Task 23

### 1. **Props في Class Components**
```javascript
this.props.propertyName
```
- استخدام `this` للوصول إلى props

### 2. **State في Class Components**
```javascript
this.state = { ... }
this.setState({ ... })
```
- تهيئة في constructor
- تحديث باستخدام setState

### 3. **this Keyword**
- فهم متى وكيف نستخدم `this`
- حل مشاكل this binding

### 4. **Constructor**
```javascript
constructor(props) {
  super(props);
  this.state = { ... };
}
```
- تهيئة الـ state
- استدعاء super(props)

### 5. **Class Methods**
- كتابة methods في class
- استدعاء methods باستخدام this

### 6. **Comparison**
- الفرق بين Functional و Class
- متى نستخدم كل واحد

## المقارنة الشاملة: Task 22 vs Task 23

| Feature | Task 22 (Functional) | Task 23 (Class) |
|---------|---------------------|-----------------|
| **Component Type** | Function | Class |
| **State** | `useState` | `this.state` |
| **Update State** | `setState(value)` | `this.setState({ ... })` |
| **Props** | `props.name` | `this.props.name` |
| **Methods** | Functions | Class methods |
| **Constructor** | ❌ لا يحتاج | ✅ يحتاج |
| **this** | ❌ لا يستخدم | ✅ يستخدم |
| **Lines of Code** | أقل | أكثر |
| **Complexity** | أبسط | أكثر تعقيداً |
| **Modern** | ✅ حديث | ⚠️ قديم |
| **Recommended** | ✅ | ❌ |

## متى تستخدم Class Components؟

### ✅ استخدم Class Components عندما:
- تعمل على مشروع قديم
- تحتاج لفهم كود موجود
- تتعلم React من الأساس

### ❌ لا تستخدم Class Components في:
- المشاريع الجديدة
- الكود الحديث
- عندما يمكنك استخدام Hooks

## Best Practices

### ✅ Do:

```javascript
// Constructor صحيح
constructor(props) {
  super(props);  // ⚠️ لا تنسى
  this.state = { ... };
}

// setState صحيح
this.setState({ text: 'new' });

// Arrow function لحل this binding
<Button onPress={() => this.handleClick()} />
```

### ❌ Don't:

```javascript
// ❌ نسيان super
constructor(props) {
  this.state = { ... };  // Error!
}

// ❌ تعديل state مباشرة
this.state.text = 'new';

// ❌ this binding خاطئ
<Button onPress={this.handleClick} />  // this = undefined
```

## المصادر

- [React Native Props](https://www.javatpoint.com/react-native-props)
- [React Class Components](https://react.dev/reference/react/Component)
- [this in JavaScript](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/this)

## مقارنة شاملة لجميع المهام

| Task | Type | Communication | State | Props |
|------|------|--------------|-------|-------|
| **22** | Functional | Child→Parent | useState | props |
| **23** | Class | Child→Parent | this.state | this.props |

## ملاحظات

- تم اتباع Guidelines المطلوبة:
  - ✅ استخدام Class Components
  - ✅ استخدام this.props و this.state
  - ✅ Constructor صحيح
  - ✅ Child to Parent communication
  - ✅ TextInput implementation
  - ✅ كود نظيف ومنظم

## الخلاصة

**Task 23** يعلمك كيفية استخدام Props مع Class Components. على الرغم من أن Functional Components هي الطريقة الحديثة، فإن فهم Class Components مهم لقراءة وصيانة الكود القديم. الفرق الرئيسي هو استخدام `this` للوصول إلى props و state! 🎯

