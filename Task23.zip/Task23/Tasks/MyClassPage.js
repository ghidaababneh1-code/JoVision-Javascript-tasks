import React, { Component } from 'react';
import { View, TextInput, Text, StyleSheet } from 'react-native';

class MyClassPage extends Component {
  handleTextChange(text) {
    this.props.onTextChange(text);
  }

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>MyClassPage</Text>
        <Text style={styles.label}>Enter text below:</Text>
        <TextInput
          style={styles.input}
          placeholder="Type something..."
          onChangeText={(text) => this.handleTextChange(text)}
        />
        <Text style={styles.info}>
          The text you type will appear in the parent component!
        </Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fce4ec',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#c2185b',
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    color: '#d81b60',
    marginBottom: 10,
  },
  input: {
    width: '100%',
    height: 50,
    borderWidth: 2,
    borderColor: '#f06292',
    borderRadius: 8,
    paddingHorizontal: 15,
    fontSize: 16,
    backgroundColor: '#fff',
    marginBottom: 20,
  },
  info: {
    fontSize: 14,
    color: '#f48fb1',
    fontStyle: 'italic',
    textAlign: 'center',
  },
});

export default MyClassPage;

