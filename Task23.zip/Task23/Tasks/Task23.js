import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import MyClassPage from './MyClassPage';

class Task23 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      textFromChild: '',
    };
  }

  handleTextUpdate(newText) {
    this.setState({ textFromChild: newText });
  }

  render() {
    return (
      <View style={styles.container}>
        <View style={styles.parentSection}>
          <Text style={styles.parentTitle}>Parent Component (Class)</Text>
          <Text style={styles.label}>Text from child:</Text>
          <View style={styles.textDisplay}>
            <Text style={styles.displayedText}>
              {this.state.textFromChild || 'No text yet...'}
            </Text>
          </View>
        </View>
        <MyClassPage onTextChange={(text) => this.handleTextUpdate(text)} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  parentSection: {
    padding: 20,
    backgroundColor: '#f5f5f5',
    borderBottomWidth: 2,
    borderBottomColor: '#e0e0e0',
  },
  parentTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  label: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  textDisplay: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    minHeight: 50,
  },
  displayedText: {
    fontSize: 16,
    color: '#333',
  },
});

export default Task23;

