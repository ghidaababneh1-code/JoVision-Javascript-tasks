# Task 25 - Refs with Class Components (createRef)

## الوصف

هذا المكون يحقق متطلبات Task 25 من مهام JoVision React Native. يقوم بتكرار Task 24 ولكن باستخدام **Class Components** بدلاً من Functional Components، مع استخدام **createRef** بدلاً من **useRef**.

## المتطلبات

- **TextInput في Parent**: حقل إدخال في المكون الأب (Class Component)
- **Text Component في Child**: عرض النص فقط (Class Component)
- **Parent to Child Communication**: تمرير البيانات من Parent إلى Child
- **createRef**: استخدام React.createRef() في Class Component
- **Direct Method Call**: استدعاء methods في Child مباشرة

## التقنيات المستخدمة

- **Class Components**: للـ Parent والـ Child
- **React.createRef()**: إنشاء ref في Class Component
- **this.childRef**: الوصول إلى ref عبر this
- **ref.current**: الوصول إلى instance المكون
- **Direct Method Call**: استدعاء updateText() مباشرة

## هيكل الملفات

```
Tasks/
├── Task25.js          (Parent Class Component مع createRef)
└── MyClassPage.js     (Child Class Component)
```

## الكود

### 1. MyClassPage.js (Child Class Component)

```javascript
import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';

class MyClassPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      displayText: '',
    };
  }

  updateText(newText) {
    this.setState({ displayText: newText });
  }

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>MyClassPage</Text>
        <Text style={styles.label}>Text from parent:</Text>
        <View style={styles.textDisplay}>
          <Text style={styles.displayedText}>
            {this.state.displayText || 'No text yet...'}
          </Text>
        </View>
        <Text style={styles.info}>
          This text is updated via ref (Class Component)!
        </Text>
      </View>
    );
  }
}

export default MyClassPage;
```

### 2. Task25.js (Parent Class Component)

```javascript
import React, { Component } from 'react';
import { View, TextInput, Text, StyleSheet } from 'react-native';
import MyClassPage from './MyClassPage';

class Task25 extends Component {
  constructor(props) {
    super(props);
    this.childRef = React.createRef();
  }

  handleTextChange(text) {
    if (this.childRef.current) {
      this.childRef.current.updateText(text);
    }
  }

  render() {
    return (
      <View style={styles.container}>
        <View style={styles.parentSection}>
          <Text style={styles.parentTitle}>Parent Component (Class)</Text>
          <Text style={styles.label}>Type here:</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter text..."
            onChangeText={(text) => this.handleTextChange(text)}
          />
          <Text style={styles.info}>
            Text is sent to child via ref (createRef)!
          </Text>
        </View>
        <MyClassPage ref={this.childRef} />
      </View>
    );
  }
}

export default Task25;
```

## شرح الكود بالتفصيل

### Task 24 (Functional) vs Task 25 (Class)

#### Parent Component

**Task 24 (Functional with useRef):**
```javascript
function Task24() {
  const childRef = useRef(null);
  
  function handleTextChange(text) {
    childRef.current.updateText(text);
  }
  
  return <MyFunctionPage ref={childRef} />;
}
```

**Task 25 (Class with createRef):**
```javascript
class Task25 extends Component {
  constructor(props) {
    super(props);
    this.childRef = React.createRef();
  }
  
  handleTextChange(text) {
    this.childRef.current.updateText(text);
  }
  
  render() {
    return <MyClassPage ref={this.childRef} />;
  }
}
```

#### Child Component

**Task 24 (Functional with forwardRef):**
```javascript
const MyFunctionPage = forwardRef((props, ref) => {
  const [displayText, setDisplayText] = useState('');
  
  useImperativeHandle(ref, () => ({
    updateText(newText) {
      setDisplayText(newText);
    },
  }));
  
  return <Text>{displayText}</Text>;
});
```

**Task 25 (Class - Built-in Ref):**
```javascript
class MyClassPage extends Component {
  constructor(props) {
    super(props);
    this.state = { displayText: '' };
  }
  
  updateText(newText) {
    this.setState({ displayText: newText });
  }
  
  render() {
    return <Text>{this.state.displayText}</Text>;
  }
}
```

## الفروقات الرئيسية

### 1. Creating Ref

| Functional (Task 24) | Class (Task 25) |
|---------------------|-----------------|
| `const ref = useRef(null)` | `this.ref = React.createRef()` |
| في body المكون | في constructor |
| Hook | Class method |

### 2. Accessing Ref

| Functional (Task 24) | Class (Task 25) |
|---------------------|-----------------|
| `ref.current` | `this.ref.current` |
| مباشرة | عبر this |

### 3. Child Component

| Functional (Task 24) | Class (Task 25) |
|---------------------|-----------------|
| يحتاج `forwardRef` | ❌ لا يحتاج |
| يحتاج `useImperativeHandle` | ❌ لا يحتاج |
| methods في useImperativeHandle | methods عادية في class |

### 4. Complexity

| Functional (Task 24) | Class (Task 25) |
|---------------------|-----------------|
| أكثر تعقيداً ⭐⭐⭐⭐ | أبسط ⭐⭐⭐ |
| forwardRef + useImperativeHandle | createRef فقط |

## لماذا Class Components أبسط في Refs؟

### Class Components:
```javascript
// Parent
this.childRef = React.createRef();
<Child ref={this.childRef} />
this.childRef.current.method();

// Child
updateText(text) {
  this.setState({ text });
}
```
✅ **بسيط ومباشر** - لا يحتاج forwardRef أو useImperativeHandle

### Functional Components:
```javascript
// Parent
const childRef = useRef(null);
<Child ref={childRef} />
childRef.current.method();

// Child
const Child = forwardRef((props, ref) => {
  useImperativeHandle(ref, () => ({
    updateText(text) { ... }
  }));
});
```
❌ **أكثر تعقيداً** - يحتاج forwardRef + useImperativeHandle

## Built-in Reference في Class Components

**ما معنى "Built-in Reference"؟**

Class Components في React Native لها **مرجع مدمج** (built-in reference) بشكل افتراضي. هذا يعني:

1. **لا تحتاج forwardRef** - يمكن تمرير ref مباشرة
2. **لا تحتاج useImperativeHandle** - جميع methods متاحة تلقائياً
3. **ref.current** يشير إلى **instance الـ class** مباشرة

```javascript
// Parent
this.childRef.current  // → instance of MyClassPage
this.childRef.current.updateText()  // ✅ يعمل مباشرة
this.childRef.current.setState()    // ✅ يعمل أيضاً
this.childRef.current.state         // ✅ يمكن الوصول إليه
```

## React.createRef()

### ما هو createRef؟

`React.createRef()` هو method في React لإنشاء ref object في Class Components.

### الصيغة:

```javascript
constructor(props) {
  super(props);
  this.myRef = React.createRef();
}
```

### الاستخدام:

```javascript
// 1. إنشاء ref في constructor
this.childRef = React.createRef();

// 2. تمريره للمكون
<MyClassPage ref={this.childRef} />

// 3. الوصول إلى instance
this.childRef.current  // → MyClassPage instance

// 4. استدعاء methods
this.childRef.current.updateText('Hello');
```

## Data Flow في Task 25

```
┌────────────────────────────────┐
│  Parent (Task25 - Class)       │
│                                │
│  1. createRef in constructor   │
│  2. User types in TextInput    │
│  3. handleTextChange(text)     │
│  4. this.childRef.current.     │
│     updateText(text)           │
└────────────────────────────────┘
            │
            │ ref.current.updateText(text)
            ↓
┌────────────────────────────────┐
│  Child (MyClassPage - Class)   │
│                                │
│  1. Ref points to instance     │
│  2. updateText() called        │
│  3. this.setState({ ... })     │
│  4. Re-render                  │
└────────────────────────────────┘
```

## ما تعلمته من Task 25

### 1. **React.createRef()**
```javascript
this.myRef = React.createRef();
```
- إنشاء ref في Class Components

### 2. **Built-in Reference**
- Class Components لها مرجع مدمج
- لا تحتاج forwardRef أو useImperativeHandle

### 3. **Direct Method Access**
```javascript
this.childRef.current.updateText();
```
- استدعاء methods مباشرة

### 4. **Simpler Refs**
- Refs في Class أبسط من Functional
- أقل كود وأقل تعقيد

### 5. **Class Component Advantage**
- هذه إحدى المزايا القليلة للـ Class Components

## المقارنة الشاملة

| Feature | Task 24 (Functional) | Task 25 (Class) |
|---------|---------------------|-----------------|
| **Parent Type** | Functional | Class |
| **Child Type** | Functional | Class |
| **Create Ref** | `useRef(null)` | `React.createRef()` |
| **Access Ref** | `ref.current` | `this.ref.current` |
| **forwardRef** | ✅ يحتاج | ❌ لا يحتاج |
| **useImperativeHandle** | ✅ يحتاج | ❌ لا يحتاج |
| **Lines of Code** | ~30 | ~20 |
| **Complexity** | ⭐⭐⭐⭐ | ⭐⭐⭐ |
| **Modern** | ✅ | ⚠️ |

## متى تستخدم كل طريقة؟

### useRef (Functional) - Task 24:
- ✅ مشاريع جديدة
- ✅ كود حديث
- ✅ عند استخدام Hooks

### createRef (Class) - Task 25:
- ✅ مشاريع قديمة
- ✅ كود موجود بـ Class Components
- ✅ عند الحاجة لبساطة أكثر في Refs

## Best Practices

### ✅ Do:

```javascript
// تحقق من ref قبل الاستخدام
if (this.childRef.current) {
  this.childRef.current.updateText(text);
}

// إنشاء ref في constructor
constructor(props) {
  super(props);
  this.childRef = React.createRef();
}

// استخدم this للوصول إلى ref
this.childRef.current
```

### ❌ Don't:

```javascript
// ❌ لا تنشئ ref خارج constructor
this.myRef = React.createRef();  // خارج constructor

// ❌ لا تنسى this
childRef.current  // ❌ خطأ
this.childRef.current  // ✅ صحيح

// ❌ لا تنسى التحقق من ref
this.childRef.current.method();  // قد يكون null
```

## المصادر

- [React createRef](https://react.dev/reference/react/createRef)
- [React Refs and the DOM](https://react.dev/learn/manipulating-the-dom-with-refs)

## مقارنة جميع أنماط Refs

| Task | Parent | Child | Method | Complexity |
|------|--------|-------|--------|-----------|
| **24** | Functional | Functional | useRef + forwardRef | ⭐⭐⭐⭐ |
| **25** | Class | Class | createRef | ⭐⭐⭐ |

## ملاحظات

- تم اتباع Guidelines المطلوبة:
  - ✅ استخدام Class Components
  - ✅ استخدام React.createRef()
  - ✅ Parent to Child communication
  - ✅ استدعاء methods مباشرة
  - ✅ كود نظيف ومنظم

## الخلاصة

**Task 25** يعلمك كيفية استخدام Refs مع Class Components باستخدام **React.createRef()**. هذه الطريقة **أبسط** من Task 24 لأن Class Components لها **مرجع مدمج** (built-in reference) - لا تحتاج forwardRef أو useImperativeHandle! هذه إحدى المزايا القليلة للـ Class Components. 🎯

