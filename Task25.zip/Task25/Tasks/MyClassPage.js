import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';

class MyClassPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      displayText: '',
    };
  }

  updateText(newText) {
    this.setState({ displayText: newText });
  }

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>MyClassPage</Text>
        <Text style={styles.label}>Text from parent:</Text>
        <View style={styles.textDisplay}>
          <Text style={styles.displayedText}>
            {this.state.displayText || 'No text yet...'}
          </Text>
        </View>
        <Text style={styles.info}>
          This text is updated via ref (Class Component)!
        </Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff3e0',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#e65100',
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    color: '#f57c00',
    marginBottom: 10,
  },
  textDisplay: {
    width: '100%',
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: '#ff9800',
    minHeight: 60,
    marginBottom: 20,
  },
  displayedText: {
    fontSize: 18,
    color: '#e65100',
    textAlign: 'center',
  },
  info: {
    fontSize: 14,
    color: '#ffb74d',
    fontStyle: 'italic',
    textAlign: 'center',
  },
});

export default MyClassPage;

