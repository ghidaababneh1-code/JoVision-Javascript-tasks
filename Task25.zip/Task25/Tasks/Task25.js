import React, { Component } from 'react';
import { View, TextInput, Text, StyleSheet } from 'react-native';
import MyClassPage from './MyClassPage';

class Task25 extends Component {
  constructor(props) {
    super(props);
    this.childRef = React.createRef();
  }

  handleTextChange(text) {
    if (this.childRef.current) {
      this.childRef.current.updateText(text);
    }
  }

  render() {
    return (
      <View style={styles.container}>
        <View style={styles.parentSection}>
          <Text style={styles.parentTitle}>Parent Component (Class)</Text>
          <Text style={styles.label}>Type here:</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter text..."
            onChangeText={(text) => this.handleTextChange(text)}
          />
          <Text style={styles.info}>
            Text is sent to child via ref (createRef)!
          </Text>
        </View>
        <MyClassPage ref={this.childRef} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  parentSection: {
    padding: 20,
    backgroundColor: '#f5f5f5',
    borderBottomWidth: 2,
    borderBottomColor: '#e0e0e0',
  },
  parentTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  label: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  input: {
    width: '100%',
    height: 50,
    borderWidth: 2,
    borderColor: '#ff9800',
    borderRadius: 8,
    paddingHorizontal: 15,
    fontSize: 16,
    backgroundColor: '#fff',
    marginBottom: 10,
  },
  info: {
    fontSize: 12,
    color: '#999',
    fontStyle: 'italic',
  },
});

export default Task25;

