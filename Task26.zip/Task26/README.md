# Task 26 - Async/Await & Blocking vs Non-Blocking Requests

## الوصف

هذا المكون يحقق متطلبات Task 26 من مهام JoVision React Native. يقوم بإنشاء تطبيق يوضح الفرق بين **Blocking** و **Non-Blocking** requests باستخدام **async/await** و **promises**.

## المتطلبات

- **زرين**: زر للـ Non-Blocking request وزر للـ Blocking request
- **Text Component**: لعرض عنوان IP المستخدم
- **Non-Blocking Request**: طلب API لا يوقف UI
- **Blocking Request**: طلب API يوقف UI
- **API**: استخدام https://api.ipify.org/ للحصول على IP
- **async/await**: استخدام async/await syntax
- **Promises**: استخدام .then().catch()

## التقنيات المستخدمة

- **async/await**: للـ Non-Blocking request
- **Promises (.then/.catch)**: للـ Blocking request
- **fetch API**: لعمل HTTP requests
- **useState**: لإدارة الحالة
- **ActivityIndicator**: لعرض loading indicator
- **Blocking Loop**: لمحاكاة blocking behavior

## الكود

```javascript
import React, { useState } from 'react';
import { View, Button, Text, StyleSheet, ActivityIndicator } from 'react-native';

function Task26() {
  const [ipAddress, setIpAddress] = useState('');
  const [isBlocking, setIsBlocking] = useState(false);

  async function handleNonBlockingRequest() {
    try {
      setIpAddress('Loading...');
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      setIpAddress(data.ip);
    } catch (error) {
      setIpAddress('Error: ' + error.message);
    }
  }

  function handleBlockingRequest() {
    setIsBlocking(true);
    setIpAddress('Loading...');
    
    fetch('https://api.ipify.org?format=json')
      .then(response => response.json())
      .then(data => {
        // Block UI for 2 seconds
        const startTime = Date.now();
        while (Date.now() - startTime < 2000) {
          // Blocking loop
        }
        setIpAddress(data.ip);
        setIsBlocking(false);
      })
      .catch(error => {
        setIpAddress('Error: ' + error.message);
        setIsBlocking(false);
      });
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>IP Address Fetcher</Text>
      
      <Button
        title="Non-Blocking Request"
        onPress={handleNonBlockingRequest}
        disabled={isBlocking}
      />

      <Button
        title="Blocking Request"
        onPress={handleBlockingRequest}
        disabled={isBlocking}
      />

      <View style={styles.resultContainer}>
        <Text>Your IP Address:</Text>
        {isBlocking ? (
          <ActivityIndicator />
        ) : (
          <Text>{ipAddress || 'Press a button'}</Text>
        )}
      </View>
    </View>
  );
}
```

## شرح الكود بالتفصيل

### 1. Non-Blocking Request (async/await)

```javascript
async function handleNonBlockingRequest() {
  try {
    setIpAddress('Loading...');
    const response = await fetch('https://api.ipify.org?format=json');
    const data = await response.json();
    setIpAddress(data.ip);
  } catch (error) {
    setIpAddress('Error: ' + error.message);
  }
}
```

**كيف يعمل:**
1. `async` - تجعل الدالة asynchronous
2. `await` - تنتظر انتهاء الـ promise بدون blocking
3. UI يبقى responsive أثناء الانتظار
4. `try/catch` - للتعامل مع الأخطاء

**السلوك:**
- ✅ UI responsive
- ✅ يمكن التفاعل مع التطبيق
- ✅ لا يوقف JavaScript thread

### 2. Blocking Request (Promises + Blocking Loop)

```javascript
function handleBlockingRequest() {
  setIsBlocking(true);
  setIpAddress('Loading...');
  
  fetch('https://api.ipify.org?format=json')
    .then(response => response.json())
    .then(data => {
      // Block UI for 2 seconds
      const startTime = Date.now();
      while (Date.now() - startTime < 2000) {
        // Blocking loop
      }
      setIpAddress(data.ip);
      setIsBlocking(false);
    })
    .catch(error => {
      setIpAddress('Error: ' + error.message);
      setIsBlocking(false);
    });
}
```

**كيف يعمل:**
1. `.then()` - promise chain
2. **Blocking loop** - `while` loop يوقف JavaScript thread
3. UI يتجمد أثناء الـ loop
4. `.catch()` - للتعامل مع الأخطاء

**السلوك:**
- ❌ UI frozen
- ❌ لا يمكن التفاعل مع التطبيق
- ❌ يوقف JavaScript thread

## async/await vs Promises

### async/await (Modern)

```javascript
async function fetchData() {
  try {
    const response = await fetch(url);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error(error);
  }
}
```

**المزايا:**
- ✅ أسهل في القراءة
- ✅ يشبه الكود المتزامن
- ✅ try/catch للأخطاء
- ✅ أقل تعقيداً

### Promises (.then/.catch)

```javascript
function fetchData() {
  fetch(url)
    .then(response => response.json())
    .then(data => {
      return data;
    })
    .catch(error => {
      console.error(error);
    });
}
```

**المزايا:**
- ✅ يعمل في كل المتصفحات
- ✅ Promise chaining
- ⚠️ أصعب في القراءة
- ⚠️ Callback hell محتمل

## Blocking vs Non-Blocking

### Non-Blocking (الطبيعي في JavaScript)

```javascript
async function nonBlocking() {
  const data = await fetch(url);  // ✅ لا يوقف UI
  console.log(data);
}
```

**الخصائص:**
- JavaScript thread حر
- UI responsive
- يمكن تنفيذ عمليات أخرى
- الطريقة الصحيحة ✅

### Blocking (يجب تجنبه)

```javascript
function blocking() {
  const start = Date.now();
  while (Date.now() - start < 5000) {
    // ❌ يوقف كل شيء
  }
}
```

**الخصائص:**
- JavaScript thread محجوز
- UI frozen
- لا يمكن تنفيذ أي شيء
- تجربة مستخدم سيئة ❌

## لماذا JavaScript Non-Blocking؟

JavaScript هي **Single-Threaded** (خيط واحد)، لذلك:

1. **بدون async/await:**
```javascript
// ❌ سيء - يوقف كل شيء
const data = fetchDataSync();  // يوقف 5 ثواني
console.log(data);
```

2. **مع async/await:**
```javascript
// ✅ جيد - لا يوقف شيء
const data = await fetchData();  // لا يوقف UI
console.log(data);
```

## Event Loop

JavaScript تستخدم **Event Loop** لتحقيق Non-Blocking:

```
┌───────────────────────────┐
│   Call Stack              │
│   (يشغل الكود)            │
└───────────────────────────┘
            ↓
┌───────────────────────────┐
│   Web APIs                │
│   (fetch, setTimeout)     │
└───────────────────────────┘
            ↓
┌───────────────────────────┐
│   Callback Queue          │
│   (ينتظر الدور)           │
└───────────────────────────┘
            ↓
┌───────────────────────────┐
│   Event Loop              │
│   (ينقل callbacks)        │
└───────────────────────────┘
```

## fetch API

### الصيغة الأساسية:

```javascript
fetch(url)
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error(error));
```

### مع async/await:

```javascript
async function getData() {
  try {
    const response = await fetch(url);
    const data = await response.json();
    console.log(data);
  } catch (error) {
    console.error(error);
  }
}
```

### مع options:

```javascript
fetch(url, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({ key: 'value' }),
})
```

## Error Handling

### async/await (try/catch)

```javascript
async function fetchData() {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error('Network error');
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error:', error.message);
  }
}
```

### Promises (.catch)

```javascript
function fetchData() {
  fetch(url)
    .then(response => {
      if (!response.ok) {
        throw new Error('Network error');
      }
      return response.json();
    })
    .then(data => console.log(data))
    .catch(error => console.error('Error:', error.message));
}
```

## ما تعلمته من Task 26

### 1. **async/await**
```javascript
async function name() {
  const result = await promise;
}
```
- الطريقة الحديثة للتعامل مع asynchronous code

### 2. **Promises**
```javascript
promise
  .then(result => { ... })
  .catch(error => { ... });
```
- الطريقة التقليدية

### 3. **Non-Blocking**
- JavaScript بطبيعتها non-blocking
- UI يبقى responsive

### 4. **Blocking**
- يجب تجنبه
- يوقف UI ويسبب تجربة سيئة

### 5. **fetch API**
- عمل HTTP requests
- يرجع Promise

### 6. **Error Handling**
- try/catch مع async/await
- .catch() مع Promises

## Best Practices

### ✅ Do:

```javascript
// استخدم async/await
async function fetchData() {
  const data = await fetch(url);
}

// تعامل مع الأخطاء
try {
  const data = await fetch(url);
} catch (error) {
  console.error(error);
}

// تحقق من response.ok
if (!response.ok) {
  throw new Error('Error');
}
```

### ❌ Don't:

```javascript
// ❌ لا تستخدم blocking loops
while (condition) {
  // blocks UI
}

// ❌ لا تنسى error handling
const data = await fetch(url);  // قد يفشل

// ❌ لا تخلط async/await و .then()
async function bad() {
  const data = await fetch(url)
    .then(r => r.json());  // مربك
}
```

## أمثلة عملية

### 1. Multiple Requests (Sequential)

```javascript
async function fetchMultiple() {
  const user = await fetch('/api/user');
  const posts = await fetch(`/api/posts/${user.id}`);
  return posts;
}
```

### 2. Multiple Requests (Parallel)

```javascript
async function fetchParallel() {
  const [users, posts] = await Promise.all([
    fetch('/api/users'),
    fetch('/api/posts'),
  ]);
  return { users, posts };
}
```

### 3. Timeout

```javascript
async function fetchWithTimeout(url, timeout = 5000) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  
  try {
    const response = await fetch(url, {
      signal: controller.signal,
    });
    clearTimeout(id);
    return response;
  } catch (error) {
    clearTimeout(id);
    throw error;
  }
}
```

## المصادر

- [async/await vs then/catch](https://www.smashingmagazine.com/2020/11/comparison-async-await-versus-then-catch/)
- [MDN: async/await](https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Asynchronous/Async_await)
- [MDN: fetch API](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API)

## مقارنة شاملة

| Feature | async/await | Promises |
|---------|------------|----------|
| **Syntax** | `await promise` | `.then(callback)` |
| **Readability** | ✅ ممتاز | ⚠️ متوسط |
| **Error Handling** | `try/catch` | `.catch()` |
| **Chaining** | Sequential | `.then().then()` |
| **Modern** | ✅ | ⚠️ |
| **Browser Support** | Modern | All |

## ملاحظات

- تم اتباع Guidelines المطلوبة:
  - ✅ زرين للـ blocking و non-blocking
  - ✅ استخدام async/await
  - ✅ استخدام Promises
  - ✅ fetch API
  - ✅ عرض IP في Text component
  - ✅ توضيح الفرق بين الطريقتين

## الخلاصة

**Task 26** يعلمك الفرق بين **Blocking** و **Non-Blocking** code، وكيفية استخدام **async/await** و **Promises** لعمل HTTP requests. JavaScript بطبيعتها **non-blocking** بفضل **Event Loop**، واستخدام async/await هو الطريقة الحديثة والموصى بها! 🚀

