import React, { useState } from 'react';
import { View, Button, Text, StyleSheet, ActivityIndicator } from 'react-native';

function Task26() {
  const [ipAddress, setIpAddress] = useState('');
  const [isBlocking, setIsBlocking] = useState(false);

  async function handleNonBlockingRequest() {
    try {
      setIpAddress('Loading...');
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      setIpAddress(data.ip);
    } catch (error) {
      setIpAddress('Error: ' + error.message);
    }
  }

  function handleBlockingRequest() {
    setIsBlocking(true);
    setIpAddress('Loading...');
    
    // Simulate blocking by using synchronous-like behavior
    fetch('https://api.ipify.org?format=json')
      .then(response => response.json())
      .then(data => {
        // Block UI for 2 seconds to demonstrate blocking
        const startTime = Date.now();
        while (Date.now() - startTime < 2000) {
          // Blocking loop
        }
        setIpAddress(data.ip);
        setIsBlocking(false);
      })
      .catch(error => {
        setIpAddress('Error: ' + error.message);
        setIsBlocking(false);
      });
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>IP Address Fetcher</Text>
      
      <View style={styles.buttonContainer}>
        <Button
          title="Non-Blocking Request"
          onPress={handleNonBlockingRequest}
          color="#4caf50"
          disabled={isBlocking}
        />
      </View>

      <View style={styles.buttonContainer}>
        <Button
          title="Blocking Request"
          onPress={handleBlockingRequest}
          color="#f44336"
          disabled={isBlocking}
        />
      </View>

      <View style={styles.resultContainer}>
        <Text style={styles.label}>Your IP Address:</Text>
        <View style={styles.ipDisplay}>
          {isBlocking ? (
            <ActivityIndicator size="large" color="#f44336" />
          ) : (
            <Text style={styles.ipText}>
              {ipAddress || 'Press a button to fetch IP'}
            </Text>
          )}
        </View>
      </View>

      <View style={styles.infoContainer}>
        <Text style={styles.infoTitle}>Difference:</Text>
        <Text style={styles.infoText}>
          • <Text style={styles.green}>Non-Blocking:</Text> UI remains responsive
        </Text>
        <Text style={styles.infoText}>
          • <Text style={styles.red}>Blocking:</Text> UI freezes during request
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
    justifyContent: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 30,
  },
  buttonContainer: {
    marginVertical: 10,
  },
  resultContainer: {
    marginTop: 30,
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  label: {
    fontSize: 16,
    color: '#666',
    marginBottom: 10,
  },
  ipDisplay: {
    minHeight: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  ipText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2196f3',
    textAlign: 'center',
  },
  infoContainer: {
    marginTop: 30,
    padding: 15,
    backgroundColor: '#e3f2fd',
    borderRadius: 8,
  },
  infoTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  infoText: {
    fontSize: 14,
    color: '#555',
    marginVertical: 5,
  },
  green: {
    color: '#4caf50',
    fontWeight: 'bold',
  },
  red: {
    color: '#f44336',
    fontWeight: 'bold',
  },
});

export default Task26;

